PORT = 443

# name -> secret (32 hex chars)
USERS = {
    "tg":  "00000000000000000000000000000000",
    "tg2": "9245a393d02b795aeea7450ce5c36bc7"
}

# Makes the proxy harder to detect
# Can be incompatible with very old clients
SECURE_ONLY = True

# Tag for advertising, obtainable from @MTProxybot
  AD_TAG = "0fac97b9b4761c2787bb2bef616c18f8"
